package carsim;

import static carsim.InitialDemo.*;

public class CarWashSim {

    public static void main(String[] args) {

        for (T = 100; T <= 300; T = T + 100) {

            new InitialDemo();

            System.out.println("Total idle Time = "+ T0);
            AT = t + getInter_ArrivalTime(); // initializing Arrival_Time(AT) to Inter_arrival Time
            System.out.println("The Value of t Initialized "+t);//

            //Number of Iterations before t >T
            for (int i = 1; i < NoOfIterations; i++) {

                if (t > T) {
                    System.out.println("SUMMARY: ");
                    idleTime = T0 / T;
                    BusyTime = 1 - idleTime;
                    System.out.println("Current Time (t) = " + t);
                    System.out.println("Current State (N) = " + N);
                    System.out.println("Idle Time = " + String.format("%.2f", idleTime));
                    System.out.println("Busy Time(U) = " + String.format(" %.2f", BusyTime));
                    System.out.println("Total Simulation Time = " + T);
                    System.out.println("======================================================================================");
                    break;

                } else {
                    if (AT < DT) {
                        System.out.println("==================================================");
                        System.out.println("NoOfIterations =" + i);
                        System.out.println("\n" + "ARRIVAL EVENT");

                        t = AT;

                        if (N <= M) {
                            N++;
                        }

                        if (N == 1) {
                            sT = getServiceTime();
                            DT = t + sT;
                            T0 = T0 + AT - E;
                        }

                        System.out.println("t = " + t);
                        System.out.println("N = " + N);
                        System.out.println("Service Time = " + sT);
                        System.out.println("ArrTime = " + AT);
                        System.out.println("Departure Time = " + DT);
                        System.out.println("Total Idle time (T0) = " + T0);

                        AT = t + getInter_ArrivalTime();

                        System.out.println("==================================================");
                    } else {
                        System.out.println("DEPARTURE EVENT");
                        t = DT;
                        N = N - 1;
                        if (N > 0) {
                            DT = t + sT;
                        } else {
                            DT = 2143643890;
                            E = t;
                        }
                        System.out.println("N = " + N);
                        System.out.println("t = " + t);
                        System.out.println("E = " + E);
                        System.out.println("DT = " + DT);

                    }
                }

            }
            System.out.println("======================================================================================");

        }
    }
}


