package carsim;

import java.util.Random;

public class InitialDemo {


    static double T;//= 1500;//total simulation time
    static int t ;//current time
    static int E ; // last departure time
    static int M ;//limit number of cars waiting
    static int N ; // total number of cars at time t
    static int AT; // arrival time
    static int sT; // service time
    static int T0 ; // total idle time
    static int NoOfIterations; // number of iterations
    static int DT = 2147483647; // Departure Time
    static double BusyTime; //busy time of the car was machine
    static double idleTime; // idle time of the car wash machine

    public InitialDemo() {
        t=0;
        E=0;
        M=100;
        N=0;
        T0=0;
        NoOfIterations=500;
    }

    static Random random = new Random();


    public static int getInter_ArrivalTime() {  // method for generating Inter-arrival time
        return 1 + random.nextInt(8);
    }

    public static int getServiceTime() {   // method for generating Service time
        return (1 + random.nextInt(5));
    }
}
